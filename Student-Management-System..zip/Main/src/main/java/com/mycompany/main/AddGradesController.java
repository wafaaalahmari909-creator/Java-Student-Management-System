/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.*;

public class AddGradesController {

@FXML
private TextField studentIdField;

@FXML
private TextField gradeField;

@FXML
void saveGrade(){

try{

File file=
new File(
"students.txt");

File temp=
new File(
"temp.txt");

BufferedReader reader=
new BufferedReader(
new FileReader(file));

BufferedWriter writer=
new BufferedWriter(
new FileWriter(temp));

String line;

while(
(line=
reader.readLine())
!=null){

String[] data=
line.split(",");

if(
data[0].equals(
studentIdField
.getText())){

line=
data[0]
+","
+data[1]
+","
+gradeField
.getText();

}

writer.write(line);

writer.newLine();

}

reader.close();
writer.close();

file.delete();
temp.renameTo(file);

}

catch(Exception e){

e.printStackTrace();

}
}

@FXML
void goBack(
ActionEvent event){

try{

Parent root=
FXMLLoader.load(
getClass()
.getResource(
"/fxml/Dashboard.fxml"));

Stage stage=
(Stage)
studentIdField
.getScene()
.getWindow();

stage.setScene(
new Scene(root));

}

catch(Exception e){

e.printStackTrace();

}
}
}