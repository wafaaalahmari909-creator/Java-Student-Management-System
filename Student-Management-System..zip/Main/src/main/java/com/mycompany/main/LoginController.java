/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    void login(ActionEvent event){

        try{

            if(usernameField.getText().equals("admin")
                    &&
                    passwordField.getText().equals("1234")){

                Parent root=
                        FXMLLoader.load(
                                getClass().getResource(
                                        "/fxml/Dashboard.fxml"));

                Stage stage=
                        (Stage)usernameField
                                .getScene()
                                .getWindow();

                stage.setScene(
                        new Scene(root));

            }

            else{

                Alert alert=
                        new Alert(
                                Alert.AlertType.ERROR);

                alert.setContentText(
                        "Wrong Login");

                alert.show();
            }

        }

        catch(Exception e){

            e.printStackTrace();
        }
    }
}