/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.Stage;

public class DashboardController {

    public void openAddStudent(
            ActionEvent event)
            throws Exception{

        switchScene(
                event,
                "/fxml/AddStudent.fxml");
    }

    public void openAddGrades(
            ActionEvent event)
            throws Exception{

        switchScene(
                event,
                "/fxml/AddGrades.fxml");
    }

    public void openViewStudents(
            ActionEvent event)
            throws Exception{

        switchScene(
                event,
                "/fxml/ViewStudents.fxml");
    }

    public void openReports(
            ActionEvent event)
            throws Exception{

        switchScene(
                event,
                "/fxml/ViewReports.fxml");
    }

    private void switchScene(
            ActionEvent event,
            String file)
            throws Exception{

        Parent root=
                FXMLLoader.load(
                        getClass()
                                .getResource(file));

        Stage stage=
                (Stage)((Node)
                        event.getSource())
                        .getScene()
                        .getWindow();

        stage.setScene(
                new Scene(root));
    }
}