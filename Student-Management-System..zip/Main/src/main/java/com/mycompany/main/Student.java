/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

public class Student {

    private final String id;
    private final String name;
    private final double grade;

    public Student(String id,String name,double grade){

        this.id=id;
        this.name=name;
        this.grade=grade;
    }

    public String getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    public double getGrade(){
        return grade;
    }
}