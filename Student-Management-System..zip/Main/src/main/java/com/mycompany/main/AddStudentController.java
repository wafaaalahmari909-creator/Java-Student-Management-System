/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.FileWriter;

public class AddStudentController {

@FXML
private TextField idField;

@FXML
private TextField nameField;

@FXML
void saveStudent(){

try{

FileWriter writer=
new FileWriter(
"students.txt",
true);

writer.write(
idField.getText()
+","
+nameField.getText()
+",0\n");

writer.close();

Alert alert=
new Alert(
Alert.AlertType.INFORMATION);

alert.setContentText(
"Student Added");

alert.show();

idField.clear();
nameField.clear();

}

catch(Exception e){

e.printStackTrace();

}
}

@FXML
void goBack(
ActionEvent event){

try{

Parent root=
FXMLLoader.load(
getClass()
.getResource(
"/fxml/Dashboard.fxml"));

Stage stage=
(Stage)
idField
.getScene()
.getWindow();

stage.setScene(
new Scene(root));

}

catch(Exception e){

e.printStackTrace();

}
}
}