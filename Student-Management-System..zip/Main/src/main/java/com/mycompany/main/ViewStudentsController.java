/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.*;

public class ViewStudentsController {

@FXML
private TableView<Student> table;

@FXML
private TableColumn<Student,String> idColumn;

@FXML
private TableColumn<Student,String> nameColumn;

@FXML
private TableColumn<Student,Double> gradeColumn;

@FXML
private Label averageLabel;

@FXML
public void initialize(){

idColumn.setCellValueFactory(
new PropertyValueFactory<>("id"));

nameColumn.setCellValueFactory(
new PropertyValueFactory<>("name"));

gradeColumn.setCellValueFactory(
new PropertyValueFactory<>("grade"));

ObservableList<Student> list=
FXCollections.observableArrayList();

double total=0;
int count=0;

try{

BufferedReader reader=
new BufferedReader(
new FileReader(
"students.txt"));

String line;

while(
(line=reader.readLine())
!=null){

String[] data=
line.split(",");

Student s=
new Student(
data[0],
data[1],
Double.parseDouble(
data[2]));

list.add(s);

total+=s.getGrade();

count++;
}

reader.close();

}

catch(Exception e){

e.printStackTrace();

}

table.setItems(list);

if(count>0){

averageLabel.setText(
"Average: "
+(total/count));
}
}

@FXML
void goBack(ActionEvent event){

try{

Parent root=
FXMLLoader.load(
getClass()
.getResource(
"/fxml/Dashboard.fxml"));

Stage stage=
(Stage)
table.getScene()
.getWindow();

stage.setScene(
new Scene(root));

}

catch(Exception e){

e.printStackTrace();

}
}
}