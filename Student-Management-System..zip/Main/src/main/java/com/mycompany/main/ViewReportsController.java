/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.*;

public class ViewReportsController {

@FXML
private Label reportLabel;

@FXML
public void initialize(){

int count=0;

try{

BufferedReader reader=
new BufferedReader(
new FileReader(
"students.txt"));

while(
reader.readLine()
!=null){

count++;

}

reader.close();

}

catch(Exception e){

e.printStackTrace();

}

reportLabel.setText(
"Total Students: "
+count);

}

@FXML
void goBack(ActionEvent event){

try{

Parent root=
FXMLLoader.load(
getClass()
.getResource(
"/fxml/Dashboard.fxml"));

Stage stage=
(Stage)
reportLabel
.getScene()
.getWindow();

stage.setScene(
new Scene(root));

}

catch(Exception e){

e.printStackTrace();

}
}
}